config.php - configure database
login.php - allows user to login
register.php - allows user to register
welcome.php - if user is able to login redirect to welcome page
logout.php - allows user to logout
